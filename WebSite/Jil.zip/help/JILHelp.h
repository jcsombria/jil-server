#define topic1 20
#define configurations 40
#define details 100

