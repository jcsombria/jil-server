
XML-RPC Server for LabVIEW Version 1.2.0

Mark E. Smith
Sandia National Laboratories
mesmith@sandia.gov

This release fixes error handling when the server does not start and port selection fron the Set Server State.vi. 

This release is for the LabVIEW 2009 and LabVIEW 8.5 Versions.  LabVIEW 8.0 and 7.1 versions remain at release 1.1.0

******************************************************

XML-RPC Server for LabVIEW Version 1.1.0

Mark E. Smith
Sandia National Laboratories
mesmith@sandia.gov

This release fixes two primary bugs

1) Single quotes, which are allowable on attribute values according to the XML 1.0 Spec, were not correctly handled.  Thanks to Richard Graham for identifying this bug and providing a fix (now incorporated into the project).

2) The server unintentionally blocked on some method calls and became unresponsive while the method call executed.  This has been corrected and new methods will be launched asynchronously as fast as the server can process them.  If one tries to call a method that is busy, an XML-RPC fault will be returned immediately since this server does not support reentrant method calls.  If one needs re-entrancy, build a wrapper method that launches the reentrant instances.  Or just catch the fault and try again until the method becomes available.


*******************************************************

XML-RPC Server for LabVIEW Version 1.0.0

Mark E. Smith
Sandia National Laboratories
mesmith@sandia.gov

This LabVIEW Project (8.5.1 and 7.1.1) provides 

1) a LabVIEW XML-RPC server - accepts TCP/IP connections and calls XML-RPC Enabled LabVIEW functions
2) XML-RPC Message Builder tools - Allows conversion of supported LabVIEW data types to XML-RPC data types
3) XML-RPC Parser tools - converts XML-RPC data to supported LabVIEW data types
4) Method Template,vit - wraps LV VIs to create XML-RPC callable methods

This project is useful to allow any language that supports XML-RPC (most any, including Java, .NET, Perl, and  Python - see http://www.xmlrpc.com/ for details) to call a LabVIEW built function.  One example is for a Java application to control and collect data from a remote LabVIEW server.  This server could be a real-time LabVIEW server (cRIO, for example) since this server should run on any LabVIEW target (including Linux and RT) and is compatible with LabVIEW 7.X - I say should be because I have not had the opportunity to test on a RT or Linux target but there are no dependencies in the code that aren't available on LVRT or Linux.

Is XML-RPC still useful given LabVIEW 8.6's Web Services capability?  I don't know - I do know that XML-RPC is a lightweight implementation supported by many languages so the answer is probably "yes".  XML-RPC complements rather than competes with the ReSTful architecture of the new 8.6 Web Services.

Getting Started:

Use the "Set Server State.vi" to start and stop the server.  The "Call Generate Sine Wave.vi" demonstrates calling a LabVIEW function (the Sine Wave Generator) as an XML-RPC method.  The actual method called is under XML-RPC Methods - open it to see how the XML-RPC protocol is converted to LabVIEW args and the LabVIEW output is converted to XML-RPC and returned to the server.  Potentially any LabVIEW side function or VI that you create could be enclosed in this wrapper and called by anything (Java, Python, .NET, etc) that has XML-RPC support.  


License

This work is licensed under the Creative Commons Attribution 3.0 Unported License. To view a copy of this license, visit http://creativecommons.org/licenses/by/3.0/ or send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.

